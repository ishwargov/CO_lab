package processor.pipeline;

public class EX_IF_LatchType {
	boolean if_enable;
	public EX_IF_LatchType()
	{
		if_enable = false;
	}
	public void setIF_enable(boolean val){
		if_enable = true;
	}
}
